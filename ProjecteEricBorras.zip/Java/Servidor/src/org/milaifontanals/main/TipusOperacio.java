
package org.milaifontanals.main;


public enum TipusOperacio {
    
    GET_LOGIN,GET_PROJECTES,GET_TASQUES_ASSIGNADES,GET_DETALL_TASCA,GET_NOTIFICACIONS_PENDENTS
    
}
