
package org.milaifontanals.main;

import javax.swing.JFrame;
import org.milaifontanals.persist.CPGestioProjecte;


public class server {


    
    public static void main(String[] args) {

        UI ui = new UI();

    }
    

    
}
