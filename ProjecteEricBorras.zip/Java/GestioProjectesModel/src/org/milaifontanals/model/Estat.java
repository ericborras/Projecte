/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.milaifontanals.model;

import java.io.Serializable;

/**
 *
 * @author Lenovo T530
 */
public enum Estat implements Serializable{
    
    
    
    TANCADA_SENSE_SOLUCIO,TANCADA_RESOLTA,TANCADA_DUPLICADA,OBERTA_NO_ASSIGNADA,OBERTA_ASSIGNADA;
    
}
