SET FOREIGN_KEY_CHECKS=0;
drop table entrada;
drop table tasca;
drop table projecte_usuari;
drop table projecte;
drop table usuari;
drop table rol;
drop table estat;
SET FOREIGN_KEY_CHECKS=1;